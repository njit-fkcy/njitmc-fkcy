@echo off
chcp 65001 >nul 2>&1

:: Check admin privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting admin privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: Already admin
cd /d "%~dp0"
echo === QMCUnlock ===
echo.

echo [1/2] Compiling...
if not exist "build" mkdir "build"
javac -encoding UTF-8 src\*.java -d build 2>&1
if errorlevel 1 (
    echo Compile FAILED!
    pause
    exit /b 1
)
echo Compile OK.
echo.

echo [2/2] Running...
echo.
java -Dfile.encoding=UTF-8 -cp build QMCUnlock
echo.
echo Program exited.
pause
