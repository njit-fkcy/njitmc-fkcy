"""
内存扫描脚本 — 只负责收集 ekey 候选，不做测试。
Java 程序通过 ProcessBuilder 调用此脚本，读取 stdout 获取候选列表。

用法: python scan_memory.py <pid>
输出: 每行一个候选 ekey (base64 字符串)
"""
import ctypes, re, sys, urllib.parse
from ctypes import wintypes

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010

class MBI(ctypes.Structure):
    _fields_ = [("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wintypes.DWORD), ("RegionSize", ctypes.c_size_t),
                ("State", wintypes.DWORD), ("Protect", wintypes.DWORD), ("Type", wintypes.DWORD)]

MAX_REGION_SIZE = 1024 * 1024 * 1024  # 1GB

def scan(pid):
    h = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
    if not h:
        sys.stderr.write(f'OpenProcess failed: {ctypes.get_last_error()}\n')
        return
    mbi = MBI()
    addr = 0
    max_addr = ctypes.c_void_p(0x7fffffffffff).value
    # base64 patterns — min length 40 (match original decrypt_qmc2.py)
    b64_re = re.compile(rb'[A-Za-z0-9+/]{40,1000}={0,2}')
    b64_u16 = re.compile(rb'(?:[A-Za-z0-9+/]\x00){40,1000}(?:=\x00){0,2}')
    # "QQMusic EncV2,Key:" prefix — primary storage for mmp4 ekeys
    enc_v2_ascii = b'QQMusic EncV2,Key:'
    enc_v2_utf16 = 'QQMusic EncV2,Key:'.encode('utf-16-le')
    # "ekey=" URL parameter
    ekey_eq_u16 = 'ekey='.encode('utf-16-le')
    ekey_eq_a = b'ekey='
    seen = set()
    count = 0

    while addr < max_addr:
        if kernel32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi), ctypes.sizeof(mbi)) == 0:
            break
        base = mbi.BaseAddress or 0
        rs = mbi.RegionSize
        if not base or rs == 0:
            addr += 0x1000
            continue
        if mbi.State != 0x1000 or (mbi.Protect & 0x100) or mbi.Protect == 0 or rs > MAX_REGION_SIZE:
            addr = base + rs
            continue
        buf = (ctypes.c_ubyte * rs)()
        br = ctypes.c_size_t(0)
        if kernel32.ReadProcessMemory(h, ctypes.c_void_p(base), buf, rs, ctypes.byref(br)):
            data = bytes(buf[:br.value])

            # 1. "QQMusic EncV2,Key:" prefix — extract following base64
            for prefix in (enc_v2_ascii, enc_v2_utf16):
                sf = 0
                while True:
                    idx = data.find(prefix, sf)
                    if idx < 0:
                        break
                    after = idx + len(prefix)
                    if prefix == enc_v2_utf16:
                        s = data[after:after + 2000].decode('utf-16-le', errors='ignore')
                    else:
                        s = data[after:after + 1000].decode('ascii', errors='ignore')
                    mm = re.match(r'[A-Za-z0-9+/]{20,1000}={0,2}', s)
                    if mm:
                        val = mm.group(0)
                        if val not in seen:
                            seen.add(val)
                            print(val, flush=True)
                            count += 1
                    sf = idx + 1

            # 2. "ekey=" URL parameter — value goes until & or \0
            for ndl in (ekey_eq_u16, ekey_eq_a):
                sf = 0
                while True:
                    idx = data.find(ndl, sf)
                    if idx < 0:
                        break
                    after = idx + len(ndl)
                    if ndl == ekey_eq_u16:
                        s = data[after:after + 4000].decode('utf-16-le', errors='ignore')
                    else:
                        s = data[after:after + 2000].decode('ascii', errors='ignore')
                    end = len(s)
                    for ci, ch in enumerate(s):
                        if ch == '&' or ch == '\x00' or ord(ch) < 32:
                            end = ci
                            break
                    val = urllib.parse.unquote(s[:end]).replace(' ', '+')
                    if len(val) >= 40 and val not in seen:
                        seen.add(val)
                        print(val, flush=True)
                        count += 1
                    sf = idx + 1

            # 3. UTF-16 base64
            for m in b64_u16.finditer(data):
                s = m.group(0).decode('utf-16-le', errors='ignore')
                if s not in seen:
                    seen.add(s)
                    print(s, flush=True)
                    count += 1

            # 4. ASCII base64
            for m in b64_re.finditer(data):
                s = m.group(0).decode('ascii', errors='ignore')
                if s not in seen:
                    seen.add(s)
                    print(s, flush=True)
                    count += 1
        addr = base + rs

    kernel32.CloseHandle(h)
    sys.stderr.write(f'Scanned {count} candidates\n')

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.stderr.write('Usage: python scan_memory.py <pid>\n')
        sys.exit(1)
    scan(int(sys.argv[1]))
