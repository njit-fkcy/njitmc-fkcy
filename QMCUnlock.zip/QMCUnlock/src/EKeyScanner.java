import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * EKey scanner — calls Python scan_memory.py to collect candidates,
 * then multi-threaded tests each candidate against the encrypted header.
 *
 * Adaptive optimization: collects hit positions, after 3 hits calculates
 * average + stddev, then only tests [avg-halfWidth, avg+halfWidth] range.
 * halfWidth = max(100, stddev*2). If not found, falls back to full scan.
 */
public class EKeyScanner {

    private static final List<Integer> hitPositions = new ArrayList<>();
    private static int fastStart = -1;  // -1 = no fast mode
    private static int fastEnd = -1;

    public static String findEkey(int pid, byte[] encHeader, int maxWorkers, String scriptDir) {
        List<String> candidates = collectCandidates(pid, scriptDir);
        if (candidates.isEmpty()) {
            System.out.println("  未找到候选 ekey");
            return null;
        }

        int total = candidates.size();

        if (fastStart >= 0) {
            // Fast mode: test [fastStart, fastEnd) first
            int start = Math.max(0, fastStart);
            int end = Math.min(total, fastEnd);
            System.out.println("  " + total + " 个候选，快速模式测试 [" + start + ", " + end + ")...");

            int hitPos = testRange(candidates, start, end, encHeader, maxWorkers);
            if (hitPos >= 0) {
                addHitPos(hitPos);
                System.out.println("  ekey 找到！(位置 " + hitPos + ")");
                return candidates.get(hitPos);
            }

            // Fast mode miss -> test all
            System.out.println("  快速模式未命中，从头测试全部...");
            hitPos = testRange(candidates, 0, total, encHeader, maxWorkers);
            if (hitPos >= 0) {
                addHitPos(hitPos);
                System.out.println("  ekey 找到！(位置 " + hitPos + ")");
                return candidates.get(hitPos);
            }
        } else {
            // No fast mode -> test all
            System.out.println("  " + total + " 个候选，" + maxWorkers + " 线程并行测试...");
            int hitPos = testRange(candidates, 0, total, encHeader, maxWorkers);
            if (hitPos >= 0) {
                addHitPos(hitPos);
                System.out.println("  ekey 找到！(位置 " + hitPos + ")");
                return candidates.get(hitPos);
            }
        }

        System.out.println("  未找到 ekey");
        return null;
    }

    /** Test candidates in [from, to) range, return hit position or -1. */
    private static int testRange(List<String> candidates, int from, int to,
                                 byte[] encHeader, int maxWorkers) {
        if (from >= to) return -1;
        ExecutorService pool = Executors.newFixedThreadPool(maxWorkers);
        AtomicReference<String> found = new AtomicReference<>(null);
        AtomicInteger hitPos = new AtomicInteger(-1);
        AtomicInteger tested = new AtomicInteger(0);
        int batchSize = maxWorkers * 10;

        for (int i = from; i < to && found.get() == null; i += batchSize) {
            int end = Math.min(i + batchSize, to);
            List<Future<?>> futures = new ArrayList<>();
            for (int j = i; j < end; j++) {
                if (found.get() != null) break;
                final int pos = j;
                final String candidate = candidates.get(pos);
                futures.add(pool.submit(() -> {
                    if (found.get() != null) return;
                    tested.incrementAndGet();
                    byte[] dk = KeyDerivation.deriveKey(candidate);
                    if (dk != null) {
                        byte[] header = Ciphers.decryptHeader(encHeader, dk);
                        if (Ciphers.isValidAudioHeader(header)) {
                            found.set(candidate);
                            hitPos.set(pos);
                        }
                    }
                }));
            }
            for (Future<?> f : futures) {
                try { f.get(); } catch (Exception ignored) {}
            }
            if (found.get() == null && (i - from) / batchSize % 10 == 0 && tested.get() > 0) {
                System.out.println("  已测试 " + tested.get() + "/" + (to - from) + "...");
            }
        }

        pool.shutdownNow();
        return hitPos.get();
    }

    /** Record hit position and update fast range when 3+ hits collected.
     *  halfWidth = max(100, stddev*2) — expands if positions are unstable. */
    private static void addHitPos(int pos) {
        hitPositions.add(pos);
        // Keep only last 10
        while (hitPositions.size() > 10) {
            hitPositions.remove(0);
        }

        if (hitPositions.size() >= 3) {
            double avg = 0;
            for (int p : hitPositions) avg += p;
            avg /= hitPositions.size();

            // Calculate stddev
            double variance = 0;
            for (int p : hitPositions) variance += (p - avg) * (p - avg);
            variance /= hitPositions.size();
            double std = Math.sqrt(variance);

            // halfWidth = max(100, stddev*2) — expand if positions are spread out
            int halfWidth = (int) Math.max(100, std * 2);
            int newStart = (int) Math.max(0, avg - halfWidth);
            int newEnd = (int) (avg + halfWidth);

            if (newStart != fastStart || newEnd != fastEnd) {
                fastStart = newStart;
                fastEnd = newEnd;
                System.out.println("  ★ 自适应优化：" + hitPositions.size() + "次平均 " + (int)avg +
                    " 标准差 " + (int)std + "，快速范围 [" + fastStart + ", " + fastEnd + ")");
            }
        } else {
            System.out.println("  已记录 " + hitPositions.size() + "/3 次命中位置");
        }
    }

    /** Call Python scan_memory.py to collect candidates from QQ Music memory. */
    private static List<String> collectCandidates(int pid, String scriptDir) {
        List<String> candidates = new ArrayList<>();
        String script = scriptDir + File.separator + "scan_memory.py";
        System.out.println("  扫描内存 (PID=" + pid + ")");

        String[] cmds = {"python", "py"};
        Process p = null;
        for (String cmd : cmds) {
            try {
                ProcessBuilder pb = new ProcessBuilder(cmd, script, String.valueOf(pid));
                pb.redirectErrorStream(false);
                p = pb.start();
                break;
            } catch (IOException e) {}
        }
        if (p == null) {
            System.out.println("  错误: 找不到 python 或 py 命令");
            return candidates;
        }

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            BufferedReader errReader = new BufferedReader(new InputStreamReader(p.getErrorStream(), "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) candidates.add(line);
            }
            while ((line = errReader.readLine()) != null) {
                System.out.println("  [Python] " + line);
            }
            int code = p.waitFor();
            System.out.println("  扫描完成: " + candidates.size() + " 个候选 (exit=" + code + ")");
        } catch (Exception e) {
            System.out.println("  扫描内存失败: " + e.getMessage());
        }
        return candidates;
    }
}
