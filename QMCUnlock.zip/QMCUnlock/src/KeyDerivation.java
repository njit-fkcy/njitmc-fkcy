import java.util.Base64;

/**
 * Key derivation — port of key_derive.rs / decrypt_qmc2.py
 * V1: base64 decode -> TEA decrypt with simple key
 * V2: base64 decode -> "QQMusic EncV2,Key:" prefix -> double TEA -> base64 -> V1
 */
public class KeyDerivation {
    private static final byte[] SIMPLE_KEY = {
        0x69, 0x56, 0x46, 0x38, 0x2b, 0x20, 0x15, 0x0b
    };
    private static final byte[] RAW_KEY_PREFIX_V2 = "QQMusic EncV2,Key:".getBytes();
    private static final byte[] DERIVE_V2_KEY_1 = {
        0x33, 0x38, 0x36, 0x5A, 0x4A, 0x59, 0x21, 0x40,
        0x23, 0x2A, 0x24, 0x25, 0x5E, 0x26, 0x29, 0x28
    };
    private static final byte[] DERIVE_V2_KEY_2 = {
        0x2A, 0x2A, 0x23, 0x21, 0x28, 0x23, 0x24, 0x25,
        0x26, 0x5E, 0x61, 0x31, 0x63, 0x5A, 0x2C, 0x54
    };

    /** Derive decode key from base64 ekey. Returns null on failure. */
    public static byte[] deriveKey(String ekeyB64) {
        byte[] rawKeyDec;
        try {
            rawKeyDec = Base64.getDecoder().decode(ekeyB64);
        } catch (Exception e) {
            return null;
        }

        if (startsWith(rawKeyDec, RAW_KEY_PREFIX_V2)) {
            byte[] v2Payload = slice(rawKeyDec, RAW_KEY_PREFIX_V2.length, rawKeyDec.length);
            byte[] v2 = deriveKeyV2(v2Payload);
            if (v2 == null) return null;
            return deriveKeyV1(v2);
        }
        return deriveKeyV1(rawKeyDec);
    }

    private static byte[] deriveKeyV1(byte[] rawKeyDec) {
        if (rawKeyDec.length < 16) return null;
        byte[] teaKey = new byte[16];
        for (int i = 0; i < 8; i++) {
            teaKey[i << 1] = SIMPLE_KEY[i];
            teaKey[(i << 1) + 1] = rawKeyDec[i];
        }
        byte[] rest = slice(rawKeyDec, 8, rawKeyDec.length);
        byte[] rs = TEACipher.tencentTeaDecrypt(rest, teaKey);
        if (rs == null) return null;

        byte[] result = new byte[8 + rs.length];
        System.arraycopy(rawKeyDec, 0, result, 0, 8);
        System.arraycopy(rs, 0, result, 8, rs.length);
        return result;
    }

    private static byte[] deriveKeyV2(byte[] rawKeyDec) {
        byte[] buf = TEACipher.tencentTeaDecrypt(rawKeyDec, DERIVE_V2_KEY_1);
        if (buf == null) return null;
        buf = TEACipher.tencentTeaDecrypt(buf, DERIVE_V2_KEY_2);
        if (buf == null) return null;
        try {
            return Base64.getDecoder().decode(new String(buf));
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean startsWith(byte[] data, byte[] prefix) {
        if (data.length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) {
            if (data[i] != prefix[i]) return false;
        }
        return true;
    }

    private static byte[] slice(byte[] src, int from, int to) {
        byte[] r = new byte[to - from];
        System.arraycopy(src, from, r, 0, to - from);
        return r;
    }
}
