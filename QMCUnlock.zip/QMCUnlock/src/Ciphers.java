/**
 * Cipher implementations — port of cipher_static.rs, cipher_map.rs, cipher_rc4.rs
 * StaticCipher (empty key), MapCipher (short key), RC4Cipher (long key >300 bytes)
 */
public class Ciphers {

    // ==================== Static Cipher ====================
    private static final int[] STATIC_BOX = {
        0x77, 0x48, 0x32, 0x73, 0xDE, 0xF2, 0xC0, 0xC8,
        0x95, 0xEC, 0x30, 0xB2, 0x51, 0xC3, 0xE1, 0xA0,
        0x9E, 0xE6, 0x9D, 0xCF, 0xFA, 0x7F, 0x14, 0xD1,
        0xCE, 0xB8, 0xDC, 0xC3, 0x4A, 0x67, 0x93, 0xD6,
        0x28, 0xC2, 0x91, 0x70, 0xCA, 0x8D, 0xA2, 0xA4,
        0xF0, 0x08, 0x61, 0x90, 0x7E, 0x6F, 0xA2, 0xE0,
        0xEB, 0xAE, 0x3E, 0xB6, 0x67, 0xC7, 0x92, 0xF4,
        0x91, 0xB5, 0xF6, 0x6C, 0x5E, 0x84, 0x40, 0xF7,
        0xF3, 0x1B, 0x02, 0x7F, 0xD5, 0xAB, 0x41, 0x89,
        0x28, 0xF4, 0x25, 0xCC, 0x52, 0x11, 0xAD, 0x43,
        0x68, 0xA6, 0x41, 0x8B, 0x84, 0xB5, 0xFF, 0x2C,
        0x92, 0x4A, 0x26, 0xD8, 0x47, 0x6A, 0x7C, 0x95,
        0x61, 0xCC, 0xE6, 0xCB, 0xBB, 0x3F, 0x47, 0x58,
        0x89, 0x75, 0xC3, 0x75, 0xA1, 0xD9, 0xAF, 0xCC,
        0x08, 0x73, 0x17, 0xDC, 0xAA, 0x9A, 0xA2, 0x16,
        0x41, 0xD8, 0xA2, 0x06, 0xC6, 0x8B, 0xFC, 0x66,
        0x34, 0x9F, 0xCF, 0x18, 0x23, 0xA0, 0x0A, 0x74,
        0xE7, 0x2B, 0x27, 0x70, 0x92, 0xE9, 0xAF, 0x37,
        0xE6, 0x8C, 0xA7, 0xBC, 0x62, 0x65, 0x9C, 0xC2,
        0x08, 0xC9, 0x88, 0xB3, 0xF3, 0x43, 0xAC, 0x74,
        0x2C, 0x0F, 0xD4, 0xAF, 0xA1, 0xC3, 0x01, 0x64,
        0x95, 0x4E, 0x48, 0x9F, 0xF4, 0x35, 0x78, 0x95,
        0x7A, 0x39, 0xD6, 0x6A, 0xA0, 0x6D, 0x40, 0xE8,
        0x4F, 0xA8, 0xEF, 0x11, 0x1D, 0xF3, 0x1B, 0x3F,
        0x3F, 0x07, 0xDD, 0x6F, 0x5B, 0x19, 0x30, 0x19,
        0xFB, 0xEF, 0x0E, 0x37, 0xF0, 0x0E, 0xCD, 0x16,
        0x49, 0xFE, 0x53, 0x47, 0x13, 0x1A, 0xBD, 0xA4,
        0xF1, 0x40, 0x19, 0x60, 0x0E, 0xED, 0x68, 0x09,
        0x06, 0x5F, 0x4D, 0xCF, 0x3D, 0x1A, 0xFE, 0x20,
        0x77, 0xE4, 0xD9, 0xDA, 0xF9, 0xA4, 0x2B, 0x76,
        0x1C, 0x71, 0xDB, 0x00, 0xBC, 0xFD, 0x0C, 0x6C,
        0xA5, 0x47, 0xF7, 0xF6, 0x00, 0x79, 0x4A, 0x11,
    };

    private static int staticMask(int offset) {
        if (offset > 0x7FFF) offset %= 0x7FFF;
        int idx = (offset * offset + 27) & 0xFF;
        return STATIC_BOX[idx];
    }

    public static byte[] staticDecrypt(byte[] data) {
        byte[] out = data.clone();
        for (int i = 0; i < out.length; i++) {
            out[i] ^= staticMask(i);
        }
        return out;
    }

    // ==================== Map Cipher ====================
    private static int mapMask(int offset, byte[] key) {
        int n = key.length;
        int tmp = offset;
        if (tmp > 0x7FFF) tmp %= 0x7FFF;
        int idx = (tmp * tmp + 71214) % n;
        // Rust: rotate = (bits.wrapping_add(4)) % 8, bits = idx as u8 & 0x7
        int rotate = ((idx & 0x7) + 4) % 8;
        int val = key[idx] & 0xFF;
        int left = (val << rotate) & 0xFF;
        int right = val >>> rotate;
        return (left | right) & 0xFF;
    }

    public static byte[] mapDecrypt(byte[] data, byte[] key) {
        byte[] out = data.clone();
        for (int i = 0; i < out.length; i++) {
            out[i] ^= mapMask(i, key);
        }
        return out;
    }

    // ==================== RC4 Cipher ====================
    private static final int RC4_FIRST_SEGMENT_SIZE = 128;
    private static final int RC4_SEGMENT_SIZE = 5120;

    private static long rc4Hash(byte[] key) {
        int n = key.length;
        long h = 1;
        for (int i = 0; i < n; i++) {
            int v = key[i] & 0xFF;
            if (v == 0) continue;
            long nh = h * v & 0xFFFFFFFFL;
            if (nh == 0 || nh <= h) break;
            h = nh;
        }
        return h;
    }

    private static int segmentSkip(long h, byte[] key, int n, int segId) {
        int seed = key[segId % n] & 0xFF;
        long denom = (long)(segId + 1) * seed;
        if (denom == 0) return 0;
        long idx = (long)((double)h / denom * 100.0) % n;
        return (int) idx;
    }

    public static byte[] rc4Decrypt(byte[] data, byte[] key) {
        int n = key.length;
        if (n == 0) return data.clone();

        // init S-box — (i & 0xFF) as u8
        int[] state = new int[n];
        for (int i = 0; i < n; i++) state[i] = i & 0xFF;
        int j = 0;
        for (int i = 0; i < n; i++) {
            j = (j + state[i] + (key[i % n] & 0xFF)) % n;
            int tmp = state[i]; state[i] = state[j]; state[j] = tmp;
        }

        long h = rc4Hash(key);
        byte[] out = data.clone();
        int dataLen = out.length;

        // first segment: 0..128
        int endFirst = Math.min(RC4_FIRST_SEGMENT_SIZE, dataLen);
        for (int i = 0; i < endFirst; i++) {
            int skip = segmentSkip(h, key, n, i);
            out[i] ^= key[skip];
        }

        // subsequent segments
        int segmentId = 0;
        while (true) {
            int[] newBox = state.clone();
            j = 0;
            int k = 0;
            int skiplen = segmentSkip(h, key, n, segmentId);
            int segStart = segmentId * RC4_SEGMENT_SIZE;
            int segEndPredict = (segmentId + 1) * RC4_SEGMENT_SIZE;
            int segEnd;
            boolean notEnd;
            if (segEndPredict >= dataLen) {
                segEnd = dataLen;
                notEnd = false;
            } else {
                segEnd = segEndPredict;
                notEnd = true;
            }
            int segLen = segEnd - segStart;
            int ii = -skiplen;
            while (ii < segLen) {
                j = (j + 1) % n;
                k = (newBox[j] + k) % n;
                int tmp = newBox[j]; newBox[j] = newBox[k]; newBox[k] = tmp;
                if (ii >= 0 && (segStart + ii >= RC4_FIRST_SEGMENT_SIZE)) {
                    out[segStart + ii] ^= newBox[(newBox[j] + newBox[k]) % n];
                }
                ii++;
            }
            segmentId++;
            if (!notEnd) break;
        }
        return out;
    }

    // ==================== Dispatch ====================
    public static byte[] decryptFull(byte[] data, byte[] decodeKey) {
        if (decodeKey.length > 300) return rc4Decrypt(data, decodeKey);
        else if (decodeKey.length > 0) return mapDecrypt(data, decodeKey);
        else return staticDecrypt(data);
    }

    public static byte[] decryptHeader(byte[] data, byte[] decodeKey) {
        int len = Math.min(128, data.length);
        byte[] header = new byte[len];
        System.arraycopy(data, 0, header, 0, len);
        return decryptFull(header, decodeKey);
    }

    public static boolean isValidAudioHeader(byte[] header) {
        if (header.length >= 8 && header[4] == 'f' && header[5] == 't'
                && header[6] == 'y' && header[7] == 'p') return true;
        if (header.length >= 4 && header[0] == 'I' && header[1] == 'D'
                && header[2] == '3' && (header[3] == 2 || header[3] == 3 || header[3] == 4))
            return true;
        if (header.length >= 4 && header[0] == 'f' && header[1] == 'L'
                && header[2] == 'a' && header[3] == 'C') return true;
        if (header.length >= 4 && header[0] == 'O' && header[1] == 'g'
                && header[2] == 'g' && header[3] == 'S') return true;
        if (header.length >= 2 && (header[0] & 0xFF) == 0xFF
                && (header[1] & 0xE0) == 0xE0) return true;
        return false;
    }
}
