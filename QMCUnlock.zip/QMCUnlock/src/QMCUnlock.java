import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

/**
 * QMCUnlock — 批量解密 QQ 音乐加密文件
 *
 * 架构：
 *   主线程：播放→等待→扫描ekey→提交解密→立即下一首
 *   后台线程池（maxWorkers）：并行解密多个文件（I/O 密集）
 *   EKeyScanner：多线程并行测试 ekey 候选（CPU 密集，无 GIL 限制）
 *
 * 用法：java QMCUnlock
 * 需要管理员权限（通过 run.bat 提权）
 */
public class QMCUnlock {

    // 扩展名映射
    private static final Map<String, String> EXT_MAP = new HashMap<>();
    static {
        EXT_MAP.put(".mmp4", ".mp4");
        EXT_MAP.put(".mflac", ".flac");
        EXT_MAP.put(".mflac0", ".flac");
        EXT_MAP.put(".mflach", ".flac");
        EXT_MAP.put(".mgg", ".ogg");
        EXT_MAP.put(".mgg1", ".ogg");
        EXT_MAP.put(".mggl", ".ogg");
    }

    // 配置
    private static int maxWorkers = 8;
    private static int ekeyWaitSec = 7;
    private static int ekeyMaxRetries = 3;

    private static String scriptDir;
    private static String inputDir;
    private static String outputDir;
    private static String failedDir;

    public static void main(String[] args) throws Exception {
        scriptDir = System.getProperty("user.dir");
        inputDir = scriptDir + File.separator + "需要解密的文件";
        outputDir = scriptDir + File.separator + "保存的文件";
        failedDir = scriptDir + File.separator + "失败的文件";

        loadConfig();
        new File(inputDir).mkdirs();
        new File(outputDir).mkdirs();
        new File(failedDir).mkdirs();

        System.out.println("配置: 解密线程=" + maxWorkers + ", 等待=" + ekeyWaitSec + "秒");
        System.out.println("输入: " + inputDir);
        System.out.println("输出: " + outputDir);
        System.out.println("失败: " + failedDir);
        System.out.println();

        // 收集文件，按修改时间从新到旧排序
        List<File> files = new ArrayList<>();
        File inputFolder = new File(inputDir);
        if (inputFolder.exists()) {
            for (File f : inputFolder.listFiles()) {
                String name = f.getName().toLowerCase();
                for (String ext : EXT_MAP.keySet()) {
                    if (name.endsWith(ext)) {
                        files.add(f);
                        break;
                    }
                }
            }
        }
        files.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        if (files.isEmpty()) {
            System.out.println("未找到加密文件，请将文件放入: " + inputDir);
            System.out.println("支持格式: " + String.join(", ", EXT_MAP.keySet()));
            return;
        }

        System.out.println("共 " + files.size() + " 个加密文件\n");

        int pid = findQQMusicPid();
        if (pid == 0) {
            System.out.println("错误: QQ 音乐未运行，请先打开 QQ 音乐");
            return;
        }

        int skipped = 0, done = 0, failed = 0;
        List<Future<Integer>> futures = new ArrayList<>();
        Map<Future<Integer>, String> futNames = new HashMap<>();
        Map<Future<Integer>, File> futInputs = new HashMap<>();

        ExecutorService pool = Executors.newFixedThreadPool(maxWorkers);

        for (int i = 0; i < files.size(); i++) {
            File inFile = files.get(i);
            String name = inFile.getName();
            String outName = getOutputName(name);
            File outFile = new File(outputDir, outName);

            // 断点续传
            if (outFile.exists()) {
                skipped++;
                System.out.println("[" + (i+1) + "/" + files.size() + "] 跳过(已存在): " + name);
                continue;
            }

            // 检查 QQ 音乐
            pid = findQQMusicPid();
            if (pid == 0) {
                System.out.println("[" + (i+1) + "/" + files.size() + "] QQ 音乐已关闭，剩余文件复制到失败目录");
                copyFailed(inFile);
                failed++;
                for (int j = i + 1; j < files.size(); j++) {
                    File rFile = files.get(j);
                    String rOut = getOutputName(rFile.getName());
                    if (!new File(outputDir, rOut).exists()) {
                        copyFailed(rFile);
                        failed++;
                    }
                }
                break;
            }

            // 读取文件
            byte[] raw = Files.readAllBytes(inFile.toPath());
            Object[] result = MusicexParser.stripFooter(raw);
            byte[] audio = (byte[]) result[0];
            byte[] encHeader = new byte[Math.min(128, audio.length)];
            System.arraycopy(audio, 0, encHeader, 0, encHeader.length);

            // 播放
            System.out.println("[" + (i+1) + "/" + files.size() + "] 播放: " + name);
            Runtime.getRuntime().exec("cmd /c start \"\" \"" + inFile.getAbsolutePath() + "\"");

            // 等待 ekey 加载
            Thread.sleep(ekeyWaitSec * 1000L);

            // 扫描 ekey（多线程并行测试候选）
            String ekey = null;
            for (int attempt = 0; attempt < ekeyMaxRetries; attempt++) {
                if (attempt > 0) {
                    System.out.println("  重试 " + (attempt+1) + "/" + ekeyMaxRetries + "...");
                    Thread.sleep(ekeyWaitSec * 1000L);
                }
                pid = findQQMusicPid();
                if (pid == 0) {
                    System.out.println("  QQ 音乐已关闭");
                    break;
                }
                ekey = EKeyScanner.findEkey(pid, encHeader, maxWorkers, scriptDir);
                if (ekey != null) break;
            }

            if (ekey != null) {
                // 提交后台解密
                final byte[] audioData = audio;
                final String finalEkey = ekey;
                final File finalOutFile = outFile;
                Future<Integer> fut = pool.submit(() -> {
                    byte[] dk = KeyDerivation.deriveKey(finalEkey);
                    byte[] decrypted = Ciphers.decryptFull(audioData, dk);
                    Files.write(finalOutFile.toPath(), decrypted);
                    return decrypted.length;
                });
                futures.add(fut);
                futNames.put(fut, name);
                futInputs.put(fut, inFile);
                System.out.println("  提交后台解密 (队列: " + futures.size() + ")");
            } else {
                System.out.println("  ekey 未找到，复制到失败目录");
                copyFailed(inFile);
                failed++;
            }

            // 报告已完成的任务
            Iterator<Future<Integer>> it = futures.iterator();
            while (it.hasNext()) {
                Future<Integer> f = it.next();
                if (f.isDone()) {
                    String fname = futNames.get(f);
                    try {
                        int sz = f.get();
                        System.out.println("  [完成] " + fname + " (" + sz + " 字节)");
                        done++;
                    } catch (Exception e) {
                        System.out.println("  [失败] " + fname + ": " + e.getMessage());
                        copyFailed(futInputs.get(f));
                        failed++;
                    }
                    it.remove();
                }
            }
        }

        // 等待所有解密完成
        if (!futures.isEmpty()) {
            System.out.println("\n等待 " + futures.size() + " 个解密任务完成...");
            for (Future<Integer> f : futures) {
                String fname = futNames.get(f);
                try {
                    int sz = f.get();
                    System.out.println("  [完成] " + fname + " (" + sz + " 字节)");
                    done++;
                } catch (Exception e) {
                    System.out.println("  [失败] " + fname + ": " + e.getMessage());
                    copyFailed(futInputs.get(f));
                    failed++;
                }
            }
        }

        pool.shutdown();
        System.out.println("\n=== 完成: " + done + " 已解密, " + skipped + " 跳过, " + failed + " 失败 ===");
        System.out.println("输出目录: " + outputDir);
        System.out.println("失败目录: " + failedDir);
    }

    /** 读取 config.json */
    private static void loadConfig() {
        File cfg = new File(scriptDir, "config.json");
        if (!cfg.exists()) return;
        try {
            String json = new String(Files.readAllBytes(cfg.toPath()));
            // Simple JSON parsing (no external library)
            maxWorkers = jsonInt(json, "max_workers", maxWorkers);
            ekeyWaitSec = jsonInt(json, "ekey_wait_sec", ekeyWaitSec);
            ekeyMaxRetries = jsonInt(json, "ekey_max_retries", ekeyMaxRetries);
        } catch (Exception e) {
            System.out.println("读取 config.json 失败: " + e.getMessage());
        }
    }

    private static int jsonInt(String json, String key, int def) {
        int idx = json.indexOf("\"" + key + "\"");
        if (idx < 0) return def;
        int colon = json.indexOf(":", idx);
        int comma = json.indexOf(",", colon);
        if (comma < 0) comma = json.indexOf("}", colon);
        try {
            return Integer.parseInt(json.substring(colon + 1, comma).trim());
        } catch (Exception e) {
            return def;
        }
    }

    /** 查找 QQ 音乐 PID */
    private static int findQQMusicPid() {
        try {
            Process p = Runtime.getRuntime().exec(
                new String[]{"powershell", "-NoProfile", "-Command",
                 "Get-Process QQMusic -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Id"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            p.waitFor();
            if (line != null) {
                line = line.trim();
                if (line.matches("\\d+")) return Integer.parseInt(line);
            }
        } catch (Exception ignored) {}
        return 0;
    }

    private static String getOutputName(String filename) {
        int dot = filename.lastIndexOf('.');
        String base = dot > 0 ? filename.substring(0, dot) : filename;
        String ext = dot > 0 ? filename.substring(dot).toLowerCase() : "";
        String outExt = EXT_MAP.getOrDefault(ext, ".mp4");
        return base + outExt;
    }

    private static void copyFailed(File inFile) {
        try {
            Files.copy(inFile.toPath(), new File(failedDir, inFile.getName()).toPath(),
                       StandardCopyOption.REPLACE_EXISTING);
            System.out.println("  已复制到失败目录: " + inFile.getName());
        } catch (Exception e) {
            System.out.println("  复制失败: " + e.getMessage());
        }
    }
}
