/**
 * TEA cipher — port of tea_decrpyt.rs / decrypt_qmc2.py
 * 8-byte block TEA decryption with 64 rounds.
 */
public class TEACipher {
    private static final int DELTA = 0x9e3779b9;
    private static final int ROUNDS = 32;

    /** Decrypt one 8-byte block. key must be 16 bytes. */
    public static byte[] decryptBlock(byte[] input, byte[] key) {
        int v0 = readBe32(input, 0);
        int v1 = readBe32(input, 4);
        int k0 = readBe32(key, 0);
        int k1 = readBe32(key, 4);
        int k2 = readBe32(key, 8);
        int k3 = readBe32(key, 12);
        int sum = DELTA * (ROUNDS / 2);
        for (int i = 0; i < ROUNDS / 2; i++) {
            v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >>> 5) + k3);
            v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >>> 5) + k1);
            sum -= DELTA;
        }
        byte[] out = new byte[8];
        writeBe32(out, 0, v0);
        writeBe32(out, 4, v1);
        return out;
    }

    /** Tencent TEA CBC decryption (decrypt_tencent_tea in Python). */
    public static byte[] tencentTeaDecrypt(byte[] inbuf, byte[] key) {
        final int SALT_LEN = 2;
        final int ZERO_LEN = 7;
        if (inbuf.length % 8 != 0 || inbuf.length < 16) return null;

        byte[] destbuf = decryptBlock(slice(inbuf, 0, 8), key);
        int padlen = destbuf[0] & 0x7;
        int outlen = inbuf.length - 1 - padlen - SALT_LEN - ZERO_LEN;
        if (outlen <= 0) return null;

        byte[] out = new byte[outlen];
        byte[] ivPrev = new byte[8];
        byte[] ivCur = slice(inbuf, 0, 8);
        int inBufPos = 8;
        int destIdx = 1 + padlen;

        // skip salt
        int i = 1;
        while (i <= SALT_LEN) {
            if (destIdx < 8) {
                destIdx++;
                i++;
            } else { // destIdx == 8
                ivPrev = ivCur;
                ivCur = slice(inbuf, inBufPos, inBufPos + 8);
                destbuf = decryptBlock(xor8(destbuf, ivCur), key);
                inBufPos += 8;
                destIdx = 0;
            }
        }

        // decrypt output
        int outpos = 0;
        while (outpos < outlen) {
            if (destIdx < 8) {
                out[outpos] = (byte)(destbuf[destIdx] ^ ivPrev[destIdx]);
                destIdx++;
                outpos++;
            } else { // destIdx == 8
                ivPrev = ivCur;
                ivCur = slice(inbuf, inBufPos, inBufPos + 8);
                destbuf = decryptBlock(xor8(destbuf, ivCur), key);
                inBufPos += 8;
                destIdx = 0;
            }
        }

        // verify zero padding
        for (int j = 1; j <= ZERO_LEN; j++) {
            if (destbuf[j] != ivPrev[j]) return null;
        }
        return out;
    }

    private static int readBe32(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) | ((b[off+1] & 0xFF) << 16)
             | ((b[off+2] & 0xFF) << 8) | (b[off+3] & 0xFF);
    }

    private static void writeBe32(byte[] b, int off, int v) {
        b[off]   = (byte)(v >>> 24);
        b[off+1] = (byte)(v >>> 16);
        b[off+2] = (byte)(v >>> 8);
        b[off+3] = (byte) v;
    }

    private static byte[] xor8(byte[] a, byte[] b) {
        byte[] r = new byte[8];
        for (int i = 0; i < 8; i++) r[i] = (byte)(a[i] ^ b[i]);
        return r;
    }

    private static byte[] slice(byte[] src, int from, int to) {
        byte[] r = new byte[to - from];
        System.arraycopy(src, from, r, 0, to - from);
        return r;
    }
}
