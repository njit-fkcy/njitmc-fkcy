/**
 * musicex footer parser — port of ekey_fetch.rs::parse_musicex_footer
 * Detects and strips the "musicex\0" trailer from QMC2 files.
 */
public class MusicexParser {

    public static class FooterInfo {
        public int version;
        public int footerSize;
        public int songId;
        public String mediaMid;
        public String filename;
        public boolean valid;
    }

    /** Strip musicex footer. Returns {audioBytes, footerInfo}. */
    public static Object[] stripFooter(byte[] data) {
        FooterInfo info = new FooterInfo();
        if (data.length < 16) return new Object[]{data, info};

        // Check "musicex\0" magic at end
        int magicStart = data.length - 8;
        if (!matches(data, magicStart, "musicex\0")) return new Object[]{data, info};

        int versionStart = magicStart - 4;
        int footerSizeStart = versionStart - 4;
        if (footerSizeStart < 4) return new Object[]{data, info};

        int version = readLe32(data, versionStart);
        int footerSize = readLe32(data, footerSizeStart);
        int metadataSize = footerSize >= 16 ? footerSize - 16 : 0;

        info.version = version;
        info.footerSize = footerSize;

        if (version != 1 || metadataSize == 0 || metadataSize > footerSizeStart) {
            info.valid = false;
            return new Object[]{data, info};
        }

        int footerStart = data.length - footerSize;
        byte[] meta = slice(data, footerStart, footerSizeStart);

        info.songId = meta.length > 4 ? readLe32(meta, 0) : 0;
        info.mediaMid = readUtf16Le(meta, 0x0C, 60);
        info.filename = readUtf16Le(meta, 0x48, 68);
        info.valid = true;

        byte[] audio = slice(data, 0, footerStart);
        return new Object[]{audio, info};
    }

    private static boolean matches(byte[] data, int off, String s) {
        byte[] sb = s.getBytes();
        if (off + sb.length > data.length) return false;
        for (int i = 0; i < sb.length; i++) {
            if (data[off + i] != sb[i]) return false;
        }
        return true;
    }

    private static int readLe32(byte[] data, int off) {
        return (data[off] & 0xFF) | ((data[off+1] & 0xFF) << 8)
             | ((data[off+2] & 0xFF) << 16) | ((data[off+3] & 0xFF) << 24);
    }

    private static String readUtf16Le(byte[] data, int offset, int maxLen) {
        StringBuilder sb = new StringBuilder();
        int end = Math.min(offset + maxLen, data.length);
        int i = offset;
        while (i + 1 < end) {
            int code = (data[i] & 0xFF) | ((data[i+1] & 0xFF) << 8);
            if (code == 0) break;
            sb.append((char) code);
            i += 2;
        }
        return sb.toString();
    }

    private static byte[] slice(byte[] src, int from, int to) {
        byte[] r = new byte[to - from];
        System.arraycopy(src, from, r, 0, to - from);
        return r;
    }
}
